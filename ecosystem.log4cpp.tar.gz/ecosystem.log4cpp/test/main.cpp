#include <iostream>

#include "log4cpp.h"

using namespace std;

using namespace log4cpp;

int main(int argc, char** argv) {
  cout<<"log4cpp tester..."<<endl;

  Log4cpp::getInstance().debug("tester", "this is a test log.");

  return 0;
}
