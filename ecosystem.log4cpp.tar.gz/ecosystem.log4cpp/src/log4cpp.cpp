#include "log4cpp.h"

#include <stdarg.h>

#include <iostream>

using namespace std;

namespace log4cpp {

Log4cpp& Log4cpp::getInstance() {
  static Log4cpp* instance = new Log4cpp();

  return *instance;
}

void Log4cpp::info(const char* id, const char* data, ...) {
  char buffer[1024];

  va_list args;
  va_start (args, data);
  vsnprintf (buffer, sizeof(buffer), data, args);
  printf("info=>%s: %s\r\n", id, buffer);
  va_end (args);
}

void Log4cpp::debug(const char* id, const char* data, ...) {
  char buffer[1024];

  va_list args;
  va_start (args, data);
  vsnprintf (buffer, sizeof(buffer), data, args);
  printf("debug=>%s: %s\r\n", id, buffer);
  va_end (args);
}

void Log4cpp::warn(const char* id, const char* data, ...) {
  char buffer[1024];

  va_list args;
  va_start (args, data);
  vsnprintf (buffer, sizeof(buffer), data, args);
  printf("warn=>%s: %s\r\n", id, buffer);
  va_end (args);
}

void Log4cpp::error(const char* id, const char* data, ...) {
  char buffer[1024];

  va_list args;
  va_start (args, data);
  vsnprintf (buffer, sizeof(buffer), data, args);
  printf("error=>%s: %s\r\n", id, buffer);
  va_end (args);
}

void Log4cpp::fatal(const char* id, const char* data, ...) {
  char buffer[1024];

  va_list args;
  va_start (args, data);
  vsnprintf (buffer, sizeof(buffer), data, args);
  printf("fatal=>%s: %s\r\n", id, buffer);
  va_end (args);
}

Log4cpp::Log4cpp() {

}

Log4cpp::~Log4cpp() {

}

}
