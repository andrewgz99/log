#ifndef __LOG_LOG4CPP_H__
#define __LOG_LOG4CPP_H__

#include <string>

namespace log4cpp {

class Log4cpp {
public:
  static Log4cpp& getInstance();

  void info(const char* id, const char* data, ...);

  void debug(const char*, const char* data, ...);

  void warn(const char* id, const char* data, ...);

  void error(const char* id, const char* data, ...);

  void fatal(const char* id, const char* data, ...);
private:
    Log4cpp();
    virtual ~Log4cpp();
};

}

#endif/*__LOG_LOG4CPP_H__*/
